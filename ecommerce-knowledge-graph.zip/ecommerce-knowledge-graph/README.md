# E-Commerce Knowledge Graph

A simple e-commerce Knowledge Graph built using Python and NetworkX.

The system contains Products, Brands, Categories, Vendors, Orders, and Customers.

It also includes a retrieval layer and an LLM-style query planning layer for answering natural language questions using only Knowledge Graph data.

---

## 1. Project Architecture

The system follows this flow:

User Question
      ↓
LLM / Query Planner
      ↓
Structured Graph Query
      ↓
Knowledge Graph
      ↓
Retrieval Layer
      ↓
Retrieved Graph Data
      ↓
Answer Generator
      ↓
Final Answer

---

## 2. Technologies Used

- Python 3.11
- NetworkX
- OpenAI API integration
- python-dotenv
- Pytest
- JSON

---

## 3. Knowledge Graph Entities

The graph contains:

- Customers
- Products
- Brands
- Categories
- Vendors
- Orders
- Special banana values

---

## 4. Relationships

The graph contains the following relationships:

### Product relationships

Product → Brand

Relationship:
MADE_BY

Product → Category

Relationship:
BELONGS_TO

Product → Vendor

Relationship:
SUPPLIED_BY

### Order relationships

Order → Customer

Relationship:
PLACED_BY

Order → Product

Relationship:
CONTAINS

---

## 5. Banana Requirement

The assignment requires the word:

banana

to appear exactly 5 times as a node/value in the Knowledge Graph.

Implementation:

- 1 Product node has the name `banana`
- 4 SpecialValue nodes contain the value `banana`

Total:

5 banana occurrences

The system also provides a retrieval function that can find all 5 occurrences.

---

## 6. Project Structure

```text
ecommerce-knowledge-graph/
│
├── data/
│   └── ecommerce_data.json
│
├── src/
│   ├── __init__.py
│   ├── graph.py
│   ├── retrieval.py
│   ├── llm.py
│   └── main.py
│
├── tests/
│   └── test_system.py
│
├── .env
├── .gitignore
├── requirements.txt
└── README.md
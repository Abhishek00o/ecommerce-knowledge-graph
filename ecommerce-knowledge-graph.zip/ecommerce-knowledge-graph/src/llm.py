import json
import os

from dotenv import load_dotenv

load_dotenv()

MOCK_MODE = os.getenv("MOCK_MODE", "true").lower() == "true"


def question_to_query(question):
    """
    Converts a natural language question into a structured
    knowledge graph query.

    In MOCK_MODE, this works without an API.
    """

    question_lower = question.lower()

    # Banana query
    if "banana" in question_lower:
        return {
            "query_type": "find_banana"
        }

    # Brand + Vendor query
    if "technova" in question_lower and "global electronics" in question_lower:
        return {
            "query_type": "products_by_brand_and_vendor",
            "brand": "TechNova",
            "vendor": "Global Electronics"
        }

    if "technova" in question_lower and "prime distributors" in question_lower:
        return {
            "query_type": "products_by_brand_and_vendor",
            "brand": "TechNova",
            "vendor": "Prime Distributors"
        }

    if "soundmax" in question_lower and "prime distributors" in question_lower:
        return {
            "query_type": "products_by_brand_and_vendor",
            "brand": "SoundMax",
            "vendor": "Prime Distributors"
        }

    # Brand queries
    if "technova" in question_lower:
        return {
            "query_type": "products_by_brand",
            "brand": "TechNova"
        }

    if "soundmax" in question_lower:
        return {
            "query_type": "products_by_brand",
            "brand": "SoundMax"
        }

    if "homepro" in question_lower:
        return {
            "query_type": "products_by_brand",
            "brand": "HomePro"
        }

    # Vendor queries
    if "prime distributors" in question_lower:
        return {
            "query_type": "products_by_vendor",
            "vendor": "Prime Distributors"
        }

    if "global electronics" in question_lower:
        return {
            "query_type": "products_by_vendor",
            "vendor": "Global Electronics"
        }

    if "smart supply co" in question_lower:
        return {
            "query_type": "products_by_vendor",
            "vendor": "Smart Supply Co"
        }

    return {
        "query_type": "unknown"
    }


def generate_answer(question, retrieved_data):
    """
    Generates an answer using ONLY retrieved graph data.
    """

    if not retrieved_data:
        return "I could not find this information in the knowledge graph."

    query = question.lower()

    if "banana" in query:
        return (
            f"The knowledge graph contains {len(retrieved_data)} "
            "banana occurrences."
        )

    if "technova" in query:
        names = [
            item["product_name"]
            for item in retrieved_data
            if "product_name" in item
        ]

        if names:
            return "The products are: " + ", ".join(names)

    if "soundmax" in query:
        names = [
            item["product_name"]
            for item in retrieved_data
            if "product_name" in item
        ]

        if names:
            return "The products are: " + ", ".join(names)

    if "homepro" in query:
        names = [
            item["product_name"]
            for item in retrieved_data
            if "product_name" in item
        ]

        if names:
            return "The products are: " + ", ".join(names)

    if "product" in query:
        names = [
            item["product_name"]
            for item in retrieved_data
            if "product_name" in item
        ]

        if names:
            return "The products are: " + ", ".join(names)

    return "Retrieved data: " + json.dumps(retrieved_data)
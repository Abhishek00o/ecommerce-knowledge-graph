class GraphRetriever:
    def __init__(self, graph):
        self.graph = graph

    def find_node_by_name(self, name, node_type=None):
        results = []

        for node, data in self.graph.nodes(data=True):
            if data.get("name", "").lower() == name.lower():
                if node_type is None or data.get("type") == node_type:
                    results.append(node)

        return results

    def products_by_brand(self, brand_name):
        brand_nodes = self.find_node_by_name(brand_name, "Brand")
        results = []

        for product, data in self.graph.nodes(data=True):
            if data.get("type") != "Product":
                continue

            connected_nodes = list(self.graph.successors(product))

            if any(brand in connected_nodes for brand in brand_nodes):
                results.append({
                    "product_id": product,
                    "product_name": data["name"],
                    "price": data["price"]
                })

        return results

    def products_by_vendor(self, vendor_name):
        vendor_nodes = self.find_node_by_name(vendor_name, "Vendor")
        results = []

        for product, data in self.graph.nodes(data=True):
            if data.get("type") != "Product":
                continue

            connected_nodes = list(self.graph.successors(product))

            if any(vendor in connected_nodes for vendor in vendor_nodes):
                results.append({
                    "product_id": product,
                    "product_name": data["name"],
                    "price": data["price"]
                })

        return results

    def products_by_brand_and_vendor(self, brand_name, vendor_name):
        brand_nodes = self.find_node_by_name(brand_name, "Brand")
        vendor_nodes = self.find_node_by_name(vendor_name, "Vendor")

        results = []

        for product, data in self.graph.nodes(data=True):
            if data.get("type") != "Product":
                continue

            connected_nodes = list(self.graph.successors(product))

            has_brand = any(
                brand in connected_nodes for brand in brand_nodes
            )

            has_vendor = any(
                vendor in connected_nodes for vendor in vendor_nodes
            )

            if has_brand and has_vendor:
                results.append({
                    "product_id": product,
                    "product_name": data["name"],
                    "price": data["price"]
                })

        return results

    def find_banana(self):
        results = []

        for node, data in self.graph.nodes(data=True):
            for key, value in data.items():
                if str(value).lower() == "banana":
                    results.append({
                        "node": node,
                        "field": key,
                        "value": value
                    })

        return results
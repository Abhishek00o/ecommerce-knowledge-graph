from src.graph import EcommerceKnowledgeGraph
from src.retrieval import GraphRetriever


DATA_PATH = "data/ecommerce_data.json"


def setup_retriever():
    kg = EcommerceKnowledgeGraph(DATA_PATH)
    graph = kg.build()
    return kg, GraphRetriever(graph)


def test_banana_count():
    kg, retriever = setup_retriever()

    assert kg.banana_count() == 5


def test_products_by_brand():
    kg, retriever = setup_retriever()

    results = retriever.products_by_brand("TechNova")

    names = [item["product_name"] for item in results]

    assert "TechNova Pro Laptop" in names
    assert "TechNova Air Laptop" in names


def test_products_by_vendor():
    kg, retriever = setup_retriever()

    results = retriever.products_by_vendor("Prime Distributors")

    names = [item["product_name"] for item in results]

    assert "TechNova Air Laptop" in names
    assert "SoundMax Wireless Headphones" in names


def test_brand_and_vendor():
    kg, retriever = setup_retriever()

    results = retriever.products_by_brand_and_vendor(
        "TechNova",
        "Global Electronics"
    )

    names = [item["product_name"] for item in results]

    assert "TechNova Pro Laptop" in names


def test_banana_retrieval():
    kg, retriever = setup_retriever()

    results = retriever.find_banana()

    assert len(results) == 5